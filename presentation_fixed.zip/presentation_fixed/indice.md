# Índice — Presentación "¿Por qué aprender React?"

| # | Título | Concepto clave |
|---|---|---|
| 01 | Portada — ¿Por qué aprender React? | Hook inicial + logo atómico animado |
| 02 | ¿Qué es React? | Librería (no framework) UI declarativa, basada en componentes |
| 03 | El problema que resuelve | Sincronizar UI ↔ estado sin manipular el DOM manualmente |
| 04 | Competidores y alternativas | Angular · Vue · Svelte · Solid — contexto del mercado |
| 05 | ¿Por qué elegir React? | Ecosistema · comunidad · empleabilidad · flexibilidad |
| 06 | El Event Loop (JS) | Cómo JS maneja async — stack, queue, microtasks (diagrama animado) |
| 07 | Estrategia de renderizado | Virtual DOM · reconciliación · diffing (árbol animado) |
| 08 | De clases a funcional | Por qué se abandonaron las clases: legibilidad, reutilización, `this` |
| 09 | ¿Qué aportan los Hooks? | useState, useEffect, useContext, custom hooks — lógica reutilizable |
| 10 | Composición sobre herencia | Componer piezas pequeñas > heredar jerarquías complejas |
| 11 | Historia y fundadores | Timeline: Jordan Walke (2011) → Facebook (2013) → hoy |
| 12 | Comunidad | Stats: npm downloads, GitHub stars, Stack Overflow, conferencias |
| 13 | Empresas que usan React | Meta, Netflix, Airbnb, Uber, Shopify, Discord, etc. |
| 14 | Ecosistema (1/2) | Next.js, React Router, Redux/Zustand, TanStack Query |
| 15 | Ecosistema (2/2) | Testing, Styling, Mobile (RN), Forms, Animation |
| 16 | ¿Y si la IA ya lo hace por mí? | Reflexión: criterio, arquitectura, debugging, libertad |
| 17 | Cierre — Roadmap | Por dónde empezar + llamado a la acción |

---

## Navegación
- **←** / **→** : cambiar de slide
- **Espacio** : siguiente
- **Home/End** : primer / último slide
- **F** : fullscreen
- Click en flechas laterales
- Swipe en mobile

## Responsive
- **Desktop/Tablet**: cada slide ocupa 100vh/100vw, transiciones full-screen
- **Mobile (<768px)**: cada slide se adapta con padding y permite scroll vertical del contenido; transiciones se mantienen entre slides
