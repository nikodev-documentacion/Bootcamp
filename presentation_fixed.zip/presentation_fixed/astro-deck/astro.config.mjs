import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import tailwind from '@astrojs/tailwind';

// https://astro.build/config
export default defineConfig({
  // GitHub Pages: https://<user>.github.io/React-curso-2026/
  site: 'https://YOUR-USERNAME.github.io',
  base: '/React-curso-2026/',
  integrations: [
    react(),
    tailwind({ applyBaseStyles: false }),
  ],
  output: 'static',
  build: {
    assets: 'assets',
  },
});
