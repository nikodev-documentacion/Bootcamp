// ComposeButton — React component with useState toggle + inline styles
// (Same logic as astro-deck/src/components/ComposeButton.tsx, rendered with JSX/Babel)

const { useState, useEffect, useRef, useMemo, useCallback } = React;

function ComposeButton({ onToggle }) {
  const [isPressed, setIsPressed] = useState(false);

  const handleClick = () => {
    const next = !isPressed;
    setIsPressed(next);
    onToggle && onToggle(next);
  };

  const baseStyle = {
    fontFamily: "'Space Grotesk', 'Inter', sans-serif",
    fontSize: 'clamp(32px, 4.5vw, 64px)',
    fontWeight: 800,
    lineHeight: 1,
    letterSpacing: '-0.02em',
    padding: '18px 32px',
    borderRadius: 14,
    cursor: 'pointer',
    userSelect: 'none',
    WebkitTapHighlightColor: 'transparent',
    touchAction: 'manipulation',
    transition: 'transform 0.1s ease, box-shadow 0.1s ease, background 0.2s ease, border-color 0.2s ease, color 0.2s ease',
    display: 'inline-block',
  };

  const stateStyle = isPressed
    ? {
        background: '#0a0a0a',
        border: '2px solid #00c8ff',
        color: '#00c8ff',
        transform: 'translateY(4px)',
        boxShadow: 'inset 0 4px 8px rgba(0,0,0,0.5), 0 0 24px rgba(0, 200, 255, 0.35)',
        textShadow: '0 0 18px rgba(0, 200, 255, 0.9)',
      }
    : {
        background: '#0f1a22',
        border: '2px solid rgba(97, 218, 251, 0.35)',
        color: '#e6edf3',
        transform: 'translateY(0)',
        boxShadow: '0 6px 0 #000, 0 8px 18px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.06)',
        textShadow: 'none',
      };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-pressed={isPressed}
      style={{ ...baseStyle, ...stateStyle }}
    >
      Compone React
    </button>
  );
}

// -------- Slide (generic) --------
function Slide({ slide }) {
  return <div dangerouslySetInnerHTML={{ __html: slide.html }} />;
}

// -------- ClosingSlide (renders slide + portals ComposeButton) --------
function ClosingSlide({ slide }) {
  const containerRef = useRef(null);
  const [mountNode, setMountNode] = useState(null);

  useEffect(() => {
    const node = containerRef.current && containerRef.current.querySelector('#compose-button-mount');
    setMountNode(node || null);
  }, [slide.html]);

  const handleToggle = (pressed) => {
    const atom = containerRef.current && containerRef.current.querySelector('#closing-atom');
    if (!atom) return;
    if (pressed) {
      const parent = atom.parentNode;
      if (!parent) return;
      const clone = atom.cloneNode(true);
      clone.classList.remove('assemble');
      parent.replaceChild(clone, atom);
      requestAnimationFrame(() => {
        requestAnimationFrame(() => clone.classList.add('assemble'));
      });
    } else {
      atom.classList.remove('assemble');
    }
  };

  return (
    <div ref={containerRef} style={{ display: 'contents' }}>
      <div dangerouslySetInnerHTML={{ __html: slide.html }} />
      {mountNode && ReactDOM.createPortal(<ComposeButton onToggle={handleToggle} />, mountNode)}
    </div>
  );
}

// -------- Deck --------
const STORAGE_KEY = 'react-curso-2026:current-slide';

function Deck() {
  // Patch slide 17 HTML to replace the inline button with a mount-point div
  // (matches what data.ts does in the Astro version)
  const SLIDES = useMemo(() => {
    const data = (window.SLIDES_DATA || []).map(s => ({ ...s }));
    if (data[16]) {
      data[16].html = data[16].html.replace(
        /<button id="compose-btn"[\s\S]*?<\/button>/,
        '<div id="compose-button-mount"></div>'
      );
    }
    return data;
  }, []);
  const total = SLIDES.length;

  const [current, setCurrent] = useState(() => {
    const stored = Number(window.localStorage.getItem(STORAGE_KEY));
    return Number.isFinite(stored) && stored >= 0 && stored < total ? stored : 0;
  });
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const check = () => {
      const m = window.matchMedia('(max-width: 768px)').matches;
      setIsMobile(m);
      document.body.classList.toggle('mobile', m);
    };
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  useEffect(() => {
    try { window.localStorage.setItem(STORAGE_KEY, String(current)); } catch(e){}
  }, [current]);

  const goTo = useCallback((i) => setCurrent(() => Math.max(0, Math.min(total - 1, i))), [total]);
  const next = useCallback(() => goTo(current + 1), [current, goTo]);
  const prev = useCallback(() => goTo(current - 1), [current, goTo]);

  useEffect(() => {
    if (isMobile) return;
    const onKey = (e) => {
      if (e.key === 'ArrowRight' || e.key === ' ' || e.key === 'PageDown') { e.preventDefault(); next(); }
      else if (e.key === 'ArrowLeft' || e.key === 'PageUp') { e.preventDefault(); prev(); }
      else if (e.key === 'f' || e.key === 'F') {
        if (document.fullscreenElement) document.exitFullscreen();
        else document.documentElement.requestFullscreen && document.documentElement.requestFullscreen();
      }
      else if (e.key === 'Home') goTo(0);
      else if (e.key === 'End') goTo(total - 1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isMobile, next, prev, goTo, total]);

  const progressPct = ((current + 1) / total) * 100;

  return (
    <>
      <div className="progress" style={{ width: `${progressPct}%` }} />

      <div className="hud hud-top">
        <span className="brand-dot" />
        <span>REACT.JS</span>
        <span style={{ color: 'var(--text-muted)' }}>·</span>
        <span>¿POR QUÉ APRENDERLO?</span>
      </div>

      <button className="nav-arrow left" onClick={prev} aria-label="Anterior">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M10 12L6 8L10 4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>
      <button className="nav-arrow right" onClick={next} aria-label="Siguiente">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path d="M6 4L10 8L6 12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      <div className="hud-counter">
        <b>{String(current + 1).padStart(2, '0')}</b> / <span>{String(total).padStart(2, '0')}</span>
      </div>

      <div className="help">
        <kbd>←</kbd> <kbd>→</kbd> navegar · <kbd>F</kbd> fullscreen
      </div>

      <div id="deck">
        {SLIDES.map((meta, i) => {
          const isActive = i === current;
          const Comp = i === 16 ? ClosingSlide : Slide;
          return (
            <section
              key={i}
              className={`slide tx-${meta.tx}${isActive ? ' active' : ''}`}
              data-screen-label={meta.label}
              aria-hidden={!isActive && !isMobile}
            >
              <Comp slide={meta} />
            </section>
          );
        })}
      </div>
    </>
  );
}

// -------- Mount --------
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<Deck />);
